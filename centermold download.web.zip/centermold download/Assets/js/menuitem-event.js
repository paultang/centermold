export default {
	refreshHref(num) {
		for(let i = 1; i <= num; ++i) {
			let nowa = document.getElementById(`href-${i}`);
			if(nowa.className == 'myactive') {
				nowa.className = '';
				return;
			}
		}
	},
	display(id, total) {// id 总数
		console.log(id);
		let displayNode = document.getElementById(`content-${id}`);
		let nodes = displayNode.parentNode.parentNode.parentNode.parentNode.children;
		// console.log(displayNode);
		// console.log(nodes);
		let len = nodes.length;
		for(let i = 0; i < total; ++i) {
			console.log(i);
			console.log(nodes[i]);
			if(i == id-1) {
				nodes[i].style = 'border:none;padding-top: 0; display:block;';
			} else nodes[i].style = 'border:none;padding-top: 0; display:none;';
		}
	},
	init(num) {
		let that = this;
		for(let i = 1; i <= num; ++i) {
			let nowa = document.getElementById(`href-${i}`);
			nowa.addEventListener('click', function() {
				console.log('click');
				that.refreshHref(num);
				that.display(parseInt(this.id.substring(5)), num);
				this.className = 'myactive';
				console.log(nowa.className);
			});
		}
		// 取#content-xx后面的数字
		var url = window.location.hash;
		if(url) {
			let id = parseInt(url.substr(9));
			this.display(id, num);
		} else this.display(1, num);
	}
};