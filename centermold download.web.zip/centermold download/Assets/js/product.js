var navlist = document.getElementById('product-nav');
console.log(navlist.childNodes);
var son = document.createElement('li');
let text = '某某产品'
son.innerHTML = `<a href="product01.html"><i>&nbsp;</i><span>${text}</span></a>`;
navlist.appendChild(son);
